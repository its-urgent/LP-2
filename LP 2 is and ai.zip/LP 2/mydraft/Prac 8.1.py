# 8.	Write a Java/C/C++/Python program to implement DES algorithm. 
# pip install pycryptodome

