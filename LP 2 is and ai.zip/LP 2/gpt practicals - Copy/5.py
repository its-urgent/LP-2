# Elementary Chatbot for a Bookstore

def chatbot_response(user_input):
    user_input = user_input.lower()

    if "hello" in user_input or "hi" in user_input:
        return "Hello! Welcome to BookVerse 📚. How can I assist you today?"

    elif "store hours" in user_input or "timing" in user_input:
        return "We are open from 9 AM to 9 PM, Monday to Saturday."

    elif "book available" in user_input or "have" in user_input:
        return "Please provide the book name. I'll check it for you!"

    elif "order status" in user_input or "track order" in user_input:
        return "Sure! Please provide your Order ID to track your order."

    elif "location" in user_input or "address" in user_input:
        return "Our store is located at 123, Main Street, Downtown City."

    elif "thank you" in user_input or "thanks" in user_input:
        return "You're welcome! Happy reading! 📖"

    elif "bye" in user_input or "exit" in user_input:
        return "Goodbye! Visit us again at BookVerse 📚."

    else:
        return "I'm sorry, I didn't understand that. Could you please rephrase?"

def main():
    print("---- Welcome to BookVerse Chatbot ----")
    print("Type 'bye' or 'exit' to end the chat.\n")

    while True:
        user_input = input("You: ")
        response = chatbot_response(user_input)
        print("Bot:", response)

        if "bye" in user_input.lower() or "exit" in user_input.lower():
            break

if __name__ == "__main__":
    main()
